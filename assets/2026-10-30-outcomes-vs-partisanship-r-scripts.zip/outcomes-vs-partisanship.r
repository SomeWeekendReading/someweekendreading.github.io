## Created on Tuesday, October 20, 2026 at 1:36pm EDT by Weekend Editor on WeekendEditorMachine.
## UnCopyright (c) 2026, Some Weekend Reading Blog.  All rights reversed.  As if you care.

##
## Predicting various US social & economic outcomes, based on partisan control of the 3
## branches of the US government.
##

source("./pipeline-tools.r")                           # Random pipeline stuff
source("./graphics-tools.r")                           # Random graphicsusua stuff

library("plyr")                                        # For ddply (yes, I haven't moved on)
library("vcd")                                         # For assocstats()
library("glmnet")                                      # For glmnet()

## How to remove all previous results stored in globals, forcing a total recalculation.
## > rm("omnibusData", "crosstabsDone", "biclusterDone", "omnibusDataCoded", "regressionResults"); doit()
## NB: Produces numerous warnings, all of which say the dataset is really small.
doit <- function(## Inputs
                 dataDir           = "./data",         # Where we've planted the magic beans

                 ## Partisan control of 3 branches of US government
                 ## Source: Table in Wikipedia, simplified to 1977 (Carter) - 2025 (Biden).
                 ##  https://en.wikipedia.org/wiki/Party_divisions_of_United_States_Congresses#Party_divisions_by_Congress
                 ##  Downloaded 2026-Oct-20; kept only some columns.
                 ##
                 ## NB: In the Wikipedia source above, the congressional terms were denoted something
                 ##   like 1977-1979, left-inclusive and right-EXCLUSIVE.  This is a pain, so we
                 ##   hand-edited the data to denote a 2-year congressional term like 1977-1978.
                 ##   (You know, like normal people.)
                 ## NB: The dash character between the years that Wikipedia used was in fact not
                 ##   just an ASCII dash character, but a weird Unicode emdash character 0x2013.
                 ##   To avoid having to mangle every OTHER data file to match this, we also changed
                 ##   these to just plain ol' ASCII - characters.
                 ##   (You know, like normal people.)
                 ## NB: In 2001, Jeffords changed party R->D, so R had senate control for a few months,
                 ##   rest D, count term as D.  Other changes/vacancies didn't shift majority control.
                 partisanshipFile  = "partisan-predictors.tsv",

                 ## US Inflation rates
                 ## Source: https://data.bls.gov/toppicks?survey=bls
                 ## Downloaded 2026-Oct-21.
                 ##
                 ## Choose CPI-U, all urban consumers, from series normalized to 1967 = 100.
                 ## Choose "More formatting options".
                 ## LHS: "Select view of the data"
                 ##   Choose "Table Format"
                 ##   Choose 12-month percent change
                 ## RHS:
                 ##   Choose 1977 - 2024
                 ##   Choose time period: Annual Data
                 ##   Choose output type: text, tab delimited
                 inflationFile     = "bls-cpiu.tsv",

                 ## US unemployment rates
                 ## U6: https://fred.stlouisfed.org/series/U6RATE#   Downloaded 2026-Oct-22.
                 ##     series only available from 1994 - date, no idea why.  Choose 1995-2024, since
                 ##     those are the starts of congressional terms.
                 ##     Choose annual percentage.  NB comma-separated.
                 unemplU6File      = "U6RATE.csv",
                 ## LFPR: https://fred.stlouisfed.org/series/CIVPART   Downloaded 2026-Oct-22.
                 ##     Select data from 1977-01-01 to 2024-12-31, annual % readings.
                 ##     NB comma-separated.
                 unemplLFPRFile    = "CIVPART.csv",

                 ## US economy growth:
                 ## GDP: https://fred.stlouisfed.org/series/GDP#0         Downloaded 2026-Oct-22.
                 ## Real GDP:  https://fred.stlouisfed.org/series/GDPC1#  Downloaded 2026-Oct-22.
                 ##   Set dates 1977-01-01 to 2024-12-31.
                 ##   Select percent change from year ago, annual freq, aggregation method average (?).
                 ##   NB: comma-separated
                 gdpGrowthFile     = "GDP_PC1.csv",
                 gdpRealGrowthFile = "GDPC1_PC1.csv",

                 ## US stock returns (inflation adjusted, with dividends reinvested):
                 ## - VFINX   https://totalrealreturns.com/s/VFINX?start=1977-01-01
                 ## - VTSMX   https://totalrealreturns.com/n/VTSMX?start=1977-01-01
                 ## Downloaded 2026-Oct-22.
                 ##
                 ## NB: Process to get the data files here:
                 ## - Downloaded the time series with inflation adjustments & dividends reinvested
                 ## - Add Year, and ticker name as col titles
                 ## - Change space-tab into just tab
                 ## - Remove % signs
                 ## - Change + and - unicode characters into plain old ASCII + and -
                 ##
                 ## Also NB:
                 ## - VFINX starts in 1979 (conveniently start of congressional term), so have to
                 ##   record NA in 1977 and 1978.
                 ## - VTSMX starts in 1992 (unfortunately the 2nd year of a congressional term), so
                 ##   have to record NA in 1977 - 1992 (dropping the 1992 data point).
                 ##
                 ## To simplify the loading code, we've just manually edited 1992 out of VTSMX data.
                 vfinxFile         = "vfinx-total-returns.tsv",
                 vtsmxFile         = "vtsmx-total-returns.tsv",

                 ## US federal budget deficit, downloaded 2026-Oct-22.
                 ## Deficit: https://fred.stlouisfed.org/series/FYFSD
                 ##   Pick dates 1977-01-01 to 2024-12-31.
                 ##   Units millions, time period annual fiscal year.
                 ##   Time points will be @ Sept 30, the fiscal new year.  NB comma-separated.
                 ## Deficit as a % of GDP: https://fred.stlouisfed.org/series/FYFSGDA188S#
                 ##   Pick dates 1977-01-01 to 2024-12-31.
                 ##   Units millions, time period annual.
                 ##   Time points will be Jan 1 for no particular reason?  Just... "annual".
                 ##   NB comma-separated.
                 deficitFile       = "FYFSD.csv",
                 deficitGDPFile    = "FYFSGDA188S.csv",

                 minYr             = 1977,             # Datasets padded back to here with NA's
                 inflTarget        = 3.0,              # Fed target, for thresholding
                 doInteractions    = TRUE,             # just 3 branches or do doubles and triples

                 ## Outputs
                 resultsDir        = "./results",      # Where to plant the new magic beans
                 txFile            = "outcomes-vs-partisanship-transcript.txt",
                 omnibusDataFile   = "outcomes-vs-partisanship-omnibus-data.tsv",
                 biclFile          = "outcomes-vs-partisanship-bicluster.png",
                 omnibusCodedFile  = "outcomes-vs-partisanship-omnibus-coded.tsv",
                 cvPlotFile        = "outcomes-vs-partisanchip-cvplot-%s.png") {

  ##
  ## 3 functions for how to combine data in 2 years of a congressional term,
  ## and another function to use them.
  ##

  compound2 <- function(r1, r2) {                      # Compounding rates over 2 yr of congr term
    ## For inflation rates, stock returns, GDP growth rates
    ## Basically, geometric average compounding: (1 + r)^2 = (1 + r1) * (1 + r2)
    ## ... and some meepery with 100 to convert from % to fraction and back.
    round((sqrt((1 + r1/100.0) * (1 + r2/100.0)) - 1) * 100.0, digits = 1)
  }                                                    #

  average2 <- function(r1, r2) {                       # Averaging, for unemployment rates
    round((r1 + r2) / 2.0, digits = 1)                 #
  }                                                    #

  sum2 <- function(r1, r2) {                           # Summing, for budget deficits
    round(r1 + r2, digits = 1)                         #
  }                                                    #

  summarizeCongressionalTerms <- function(df, summaryFn) {
    ## Congressional term computed from year; 1977 was the 95th Congress.
    ## This is just a funky way of mapping over the correct pairs of years.
    subset(ddply(transform(df, CongrTerm = floor((Year - 1977) / 2) + 95),
                 "CongrTerm",                          # Map over pairs of years in a congress term
                 function(ctdf) {                      # Congressional term sub-dataframe
                   stopifnot(nrow(ctdf) == 2)          # Must be exactly 2 years
                   summaryFn(ctdf)                     # Call summary function, which generates
                 }),                                   #  the summary dataframe
           select = -CongrTerm)                        # Drop guide column CongrTerm
  }                                                    #

  checkFactorLevels <- Vectorize(function(f, lvls) {   # Check if a factor has exactly the levels we
    all(levels(f) == lvls)                             #  expect, and in the order we expect, so
  })                                                   #  directly comparable to similar factors

  ##
  ## A couple parsing helpers, vectorized Just to Make Sure
  ##

  isConsecutiveYearDashYear <- Vectorize(function(s) { # Check string of two 4-digit consecutive years
    grepl("^[0-9]{4}-[0-9]{4}$", s) &                  # Matches 4-digit, dash, 4-digit
    as.integer(gsub("^.*([0-9]{4})$", "\\1", s)) -     # Parse integers, check consecutive, i.e.,
      as.integer(gsub("^([0-9]{4}).*$", "\\1", s)) == 1#  must differ by 1, smallest first
  })                                                   #

  parseYear <- Vectorize(function(s) {                 # Parse integer year from string
    as.integer(gsub("^([0-9]{4}).*$", "\\1", x = s))   #  "YYYY-MM-DD"
  })                                                   #

  parseYearIdentity <- Vectorize(function(s) { s })    # Sometimes a year is just a year. -- Freud

  ##
  ## Raw data file loaders
  ##

  loadPartisanshipData <- function(dataDir, partisanshipFile) {
    f <- file.path(dataDir, partisanshipFile)          # Full pathname
    cat(sprintf("* Loading partisanship data from %s", f))
    partisanshipData <- transform(subset(read.table(f, header = TRUE, sep = "\t"),
                                         select = c("Years", "HouseParty", "SenateParty",
                                                    "PresidentParty")),
                                  Years          = as.factor(Years),
                                  HouseParty     = as.factor(HouseParty),
                                  SenateParty    = as.factor(SenateParty),
                                  PresidentParty = as.factor(PresidentParty))
    stopifnot(all(isConsecutiveYearDashYear(levels(partisanshipData$"Years"))))
    checkFactorLevels(partisanshipData$"HouseParty",     c("Democrat", "Republican"))
    checkFactorLevels(partisanshipData$"SenateParty",    c("Democrat", "Republican"))
    checkFactorLevels(partisanshipData$"PresidentParty", c("Democrat", "Republican"))
    cat(sprintf("\n  - Found and kept %d rows, of %d cols: %s\n",
                nrow(partisanshipData), ncol(partisanshipData),
                paste(colnames(partisanshipData), collapse = ", ")))
    partisanshipData                                   # Return partisanship dataframe
  }                                                    #

  load1Series <- function(seriesName, dataDir, seriesFile, separator,
                          yearParser, minYr, comboFn, comboFnName) {
    ## Subroutine for loading tab- or comma-separated value files.
    ##
    ## The files have exactly 2 columns: first indicating a year (somehow), second a value.
    ## - canonicalize the year using a parser to extract a 4-digit integer year
    ## - canonicalize the series name to what we want
    ## - if the series doesn't go backf far enough, pad it with NA's back to minimum year
    ## - combine values in consecutive pairs of years to correspond to congressional terms,
    ##   where "combine" can mean compound, average, or add.
    ##   (NB: IT IS ASSUMED the years line up with congressional terms!)
    ##
    ## We also check along the way to make sure we haven't mangled something.

    ## Load the raw data file and check the number of rows & columns, and column names
    f <- file.path(dataDir, seriesFile)                # Full pathname to series file
    cat(sprintf("\n  - Loading %s data from %s", seriesName, f))
    seriesData <- read.table(f, header = TRUE, sep = separator)
    cat(sprintf("\n    o Found %d rows of %d columns: %s",
                nrow(seriesData), ncol(seriesData), paste(colnames(seriesData), collapse = ", ")))

    ## Canonicalize first column to year via parser, canonicalize 2nd column to series name
    stopifnot(ncol(seriesData) == 2)                   # Year and value (year can be named otherwise)
    colnames(seriesData)[[2]] <- seriesName            # Canonicalize the series name, then year
    seriesData <- transform(seriesData, Year = yearParser(seriesData[, 1]))
    seriesData <- seriesData[, c("Year", seriesName)]  # Values now canonicalized *** subset()?
    cat(sprintf("\n    o After canonicalization, %d rows of %d columns: %s",
                nrow(seriesData), ncol(seriesData), paste(colnames(seriesData), collapse = ", ")))

    ## Canonicalize range of years to go back to minYr, padding with NA's if needed
    seriesMinYr <- min(seriesData$"Year")              # Min year present in data
    stopifnot(seriesMinYr >= minYr)                    # Can't have data BEFORE minYr!
    if (seriesMinYr > minYr) {                         # Need to pad out data back to minYr
      paddf                <- data.frame(Year = minYr : (seriesMinYr - 1), "Foo" = NA)
      colnames(paddf)[[2]] <- seriesName               # Put back mutual fund name
      seriesData           <- rbind(paddf, seriesData) # Pad out missing early data
      cat(sprintf("\n    o After padding back to %d with NA's, have %d rows", minYr, nrow(seriesData)))
    }                                                  #

    ## Combine pairs of years into congressional terms (compound, average, or add as appropriate)
    seriesData <- summarizeCongressionalTerms(seriesData, function(ctdf) {
        data.frame("Years" = factor(sprintf("%d-%d", ctdf[1, "Year"], ctdf[2, "Year"])),
                   "Foo"   = comboFn(ctdf[1, seriesName], ctdf[2, seriesName]))
      })                                               # Summarize over congressional terms
      colnames(seriesData)[[2]] <- seriesName          #  by combining returns
    cat(sprintf("\n    o After combining over congressional terms with %s, have %d rows",
                comboFnName, nrow(seriesData)))
    stopifnot(all(isConsecutiveYearDashYear(levels(seriesData$"Years"))))

    seriesData                                         # Return the series dataframe
  }                                                    #

  loadInflationData <- function(dataDir, inflationFile) {
    cat("\n* Loading inflation data")                  # Load inflation data
    inflationData <- load1Series("Inflation", dataDir, inflationFile, "\t",
                                 parseYearIdentity, minYr, compound2, "compounding")
    cat("\n")                                          # Clear line on transcript
    inflationData                                      # Return inflation data
  }                                                    #

  loadUnemploymentData <- function(dataDir, unemplU6File, unemplLFPRFile, minYr) {
    cat("\n* Loading unemployment data")               # Load U6 & labor force participation rate
    unemplData <- merge(load1Series("U6", dataDir, unemplU6File, ",",
                                    parseYear, minYr, average2, "averaging"),
                        load1Series("LFPR", dataDir, unemplLFPRFile, ",",
                                    parseYear, minYr, average2, "averaging"),
                       by = "Years", all = TRUE)       #  by outer join on Years
    cat(sprintf("\n  - Combined unemployment data has %d rows and %d columns: %s\n",
                nrow(unemplData), ncol(unemplData), paste(colnames(unemplData), collapse = ", ")))
    unemplData                                         # Return series for both
  }                                                    #

  loadGDPData <- function(dataDir, gdpGrowthFile, gdpRealGrowthFile) {
    cat("\n* Loading GDP data")                        # Load GDP growth & real GDP growth rates
    gdpData <- merge(load1Series("GDPGrowth",     dataDir, gdpGrowthFile, ",",
                                 parseYear, minYr, compound2, "compounding"),
                     load1Series("GDPGrowthReal", dataDir, gdpRealGrowthFile, ",",
                                 parseYear, minYr, compound2, "compounding"),
                     by = "Years", all = TRUE)         #  by outer join on Years
    cat(sprintf("\n  - Combined GDP data has %d rows and %d columns: %s\n",
                nrow(gdpData), ncol(gdpData), paste(colnames(gdpData), collapse = ", ")))
    gdpData                                            # Return series for both
  }                                                    #

  loadStockData <- function(dataDir, vfinxFile, vtsmxFile, minYr) {
    cat("\n* Loading stock market return data")        # Load VFINX and VTSMX data, and combine
    stockData <- merge(load1Series("VFINX", dataDir, vfinxFile, "\t",
                                   parseYearIdentity, minYr, compound2, "compounding"),
                       load1Series("VTSMX", dataDir, vtsmxFile, "\t",
                                   parseYearIdentity, minYr, compound2, "compounding"),
                       by = "Years", all = TRUE)       #  by outer join on Years
    cat(sprintf("\n  - Combined stock data has %d rows and %d columns: %s\n",
                nrow(stockData), ncol(stockData), paste(colnames(stockData), collapse = ", ")))
    stockData                                          # Return series for both
  }                                                    #

  loadDeficitData <- function(dataDir, deficitFile, deficitGDPFile) {
    cat("\n* Loading budget deficit data")             # Load deficit & deficit a % of GDP
    defData <- merge(load1Series("Deficit",    dataDir, deficitFile, ",",
                                 parseYear, minYr, sum2, "summing"),
                     load1Series("DeficitGDP", dataDir, deficitGDPFile, ",",
                                 parseYear, minYr, sum2, "summing"),
                     by = "Years", all = TRUE)         #  by outer join on Years
    cat(sprintf("\n  - Combined deficit data has %d rows and %d columns: %s\n",
                nrow(defData), ncol(defData), paste(colnames(defData), collapse = ", ")))
    defData                                            # Return series for both
  }                                                    #

  ##
  ## Combining lots of dataframes into an omnibus dataset, by outer join on Years column.
  ## The Years column will be something like 1977-1978, i.e., a congressional term.
  ##
  ## Outer join (merge() arg all = TRUE) to catch any mismatches.
  ##

  consolidateByYears <- function(dfList, resultsDir, omnibusDataFile) {
    cat(sprintf("\n* Consolidating %d dataframes by outer join on 'Years'", length(dfList)))
    omnibusData <- Reduce(function(x, y) {merge(x, y, by = "Years", all = TRUE) },
                          dfList,                      # Combine all by outer join on Years column
                          data.frame("Years" = factor()))
    cat(sprintf("\n  - Result dataframe has %d rows and %d columns:\n",
                nrow(omnibusData), ncol(omnibusData))) # Describe it
    showDataframeHeadTail(omnibusData)                 # Show first & last few rows

    f <- file.path(resultsDir, omnibusDataFile)        # Full pathname
    saveDataframe(omnibusData, f)                      # Save it
    cat(sprintf("  - Saved to %s\n", f))               # Show where on transcript

    omnibusData                                        # Return omnibus dataframe
  }                                                    #

  partisanCrosstabs <- function(omnibusData) {         # Test independence of House, Senate, Pres
    ## Assess statistical significance via Fisher exact test and chi^2 test.
    ## If significant, would assess strength of effect with phi or Cramér's V.

    crosstab2 <- function(omnibusData, col1, col2) {   # Crosstabulate D/R for 2 branches of govt
      cat(sprintf("\n  - %s vs %s\n", col1, col2))     # Name the columns (1st on rows, 2nd on cols)
      tbl <- table(omnibusData[, col1], omnibusData[, col2])
      print(tableRowColTotals(tbl))                    # Print the 2x2 contingency table
      print(chisq.test(tbl))                           # Chi square test of significance
      print(fisher.test(tbl))                          # Fisher exact test of significance
      print(assocstats(tbl))                           # Various strength of association stats, notably
    }                                                  #  phi and Cramér's V, if signficant

    cat(sprintf("\n* Crosstabulations of partisan control of the 3 branches"))
    crosstab2(omnibusData, "HouseParty",  "SenateParty")
    crosstab2(omnibusData, "HouseParty",  "PresidentParty")
    crosstab2(omnibusData, "SenateParty", "PresidentParty")
    cat("\n")                                          #
    TRUE                                               # Flag that this has been done
  }                                                    #

  biclusterOutcomes <- function(omnibusData, outcomeVars, resultsDir, biclFile,
                                legendFrac = 0.10, nColors = 256) {
    ## Bicluster outcome variables by Pearson correlation, pairwise complete variables
    f <- file.path(resultsDir, biclFile)               #
    cat(sprintf("* Biclustering econ correlations to %s.", f))
    withPNG(f, 1000, 1000, FALSE, function() {         #
      withPars(function() {                            #

        corMx <- round(cor(subset(omnibusData, select = outcomeVars),
                           use = "pairwise.complete.obs"), digits = 2)

        ## Must compute dendrograms OUTSIDE heatmap(), so rowInd/colInd can be used in the add.expr{}.
        ## Absolute value in rowMeans in reorder is an attempt to get variables that are
        ## anti-correlated to cluster together, too.  Appears to have been unsuccessful?
        n             <- nrow(corMx)                   #
        rowDendrogram <- reorder(as.dendrogram(hclust(dist(corMx))), rowMeans(abs(corMx)))
        rowInd        <- order.dendrogram(rowDendrogram)
        colDendrogram <- reorder(as.dendrogram(hclust(dist(t(corMx)))), colMeans(abs(corMx)))
        colInd        <- order.dendrogram(colDendrogram)
        cat(sprintf("\n  - Correlation matrix (pairwise complete observations):\n"))
        print(corMx[rowInd, colInd])                   # Same order as dendrograms will force in plot

        corrRange  <- range(corMx)                     # Range of correlations (inside [-1, +1])
        colors     <- makeSaturableHeatmapColorsBWR(nColors, corrRange[[1]], corrRange[[2]],
                                                    minSat = -1, midSat = 0, maxSat = +1)
        maxLabLen  <- max(nchar(rownames(corMx)))      #

        heatmap(corMx,                                 #
                Rowv = rowDendrogram, Colv = colDendrogram,
                symm = TRUE, revC = TRUE, scale = "none", col = colors,
                margins = 0.95 * c(maxLabLen, maxLabLen),
                main = "Economic Measures: Pearson Correlations",
                add.expr = {                           # Print correlations to 2 decimal places in
                  sapply(1 : n, function(r) {          # each box.  Basically writing
                    sapply(1 : n, function(c) {        # corMx[r, c] over cells of the heatmap.
                      ## *** n - r + 1 respects revC, swapping row/col is counter-transpose?
                      text(c, n - r + 1, labels = sprintf("%.2f", corMx[rowInd[r], colInd[c]]),
                           cex = 1.5)                  #
                    })                                 #
                  })                                   #
                  box(which = "plot")                  # Draw a box around the whole plot
                })                                     #
        par(omd = c(0.02, legendFrac, 0, 1), pty = "m", new = TRUE)
        image(x    = 0,                                # draw the color bar
              y    = seq(from = corrRange[[1]], to = corrRange[[2]], along.with = colors),
              z    = matrix(1 : length(colors), ncol = length(colors)),
              cex.axis = 0.9,                          # Smaller labels
              las  = 1,                                # Label positioning
              ylim = c(-1, +1),                        # Show range of POSSIBLE correlations
              col  = colors,                           # Heatmap colors
              xaxt = "n", ylab = NA, xlab = NA)        #
        box(which = "plot")                            #
      }, pty = "m",                                    # Maximal plotting area
         bg  = "white",                                # White background
         ps  = 18,                                     # Larger type size for file capture
         omd = c(legendFrac, 1, 0, 1),                 # Leave room for color bar legend
         mar = c(1, 2, 1, 1))                          # Pull in on margins
    })                                                 #

    TRUE                                               # Flag that this was done
  }                                                    #

  doCodings <- function(omnibusData, inflTarget, resultsDir, omnibusCodedFile) {
    ## Encode party content, binarize outcomes
    cat(sprintf("* Encoding data for logistic regression"))

    cat(sprintf(                                       # First do partisanship variables
        "\n  - Encoding 7 partisanship variables, to number controlled by Republicans/Democrats"))
    ## On the one hand, the R formula language has a way of saying ALMOST exactly this, but it
    ## would end up taking products of variables.  We want something more like SUM/DIFFERENCE, i.e.,
    ## # branches controlled by Republicans - # branches controlled by Democrats.
    ##
    ## So here we force that to happen manually.
    ##
    ## (1) Basically add up +1 for Republican and -1 for Democrat content.
    ##     - Encode House, Senate, and Presidency as +1 if Republican and -1 if Democrat.
    ##     - Then encode pairs by sum, i.e., +2 if both Republican, 0 if mixed, -2 if both Democrat.
    ##     - Then encode the trifecta as +3 if all Republican, +1 if 2 Republican / 1 Democrat,
    ##       -1 if 1 Republican / 2 Democrat, -3 if all Democrat.
    df <- subset(transform(transform(omnibusData,      # Encode indicators, drop originals
                               House     = ifelse(HouseParty     == "Republican", +1, -1),
                               Senate    = ifelse(SenateParty    == "Republican", +1, -1),
                               President = ifelse(PresidentParty == "Republican", +1, -1)),
                     HouseSenate          = House  + Senate,
                     HousePresident       = House  + President,
                     SenatePresident      = Senate + President,
                     HouseSenatePresident = House + Senate + President),
           select = -c(HouseParty, SenateParty, PresidentParty))

    cat(sprintf("\n  - Encoding output variables to Good/Bad by various specific criteria"))
    ## (2) Binarize the outcome variables to indicator variables, with values "Good" or "Bad":
    ##     - Inflation is Good if it's below the Fed inflation target, otherwise Bad
    ##       NB: This naively ignores the possibility of deflation, with which we flirted in 2007-2008!
    ##       Also, the Fed may have changed inflation targeting; here we're using 1 uniform target.
    ##     - U6 is Good if it decreased from previous term, Bad if it increased.
    ##       This means the first row of data gets NA, because we don't have the term before THAT.
    ##     - LFPR is Good if it increased from previous term, Bad if it decreased.
    ##       Again, first row gets NA, for the same reason.
    ##     - GDPGrowth & GDPGrowthReal are Good if above their respective medians, Bad if below.
    ##       Note that each term is the compounded 2-year GDP growth rate, but we're taking a
    ##       median across the dataset to set this threshold.  Basically dividing a distribution
    ##       of compound growth rates into the upper half and lower half.  Is that reasonable?
    ##     - VFINX & VTSMX are like GDP: Good if above their medians, Bad if below.
    ##     - Deficit DeficitGDP are Good if they increased (remember, deficit is a NEGATIVE number,
    ##       so the good direction is up toward 0 or even positive/surplus), and Bad if they
    ##       decreased (more negative, more debt).  This means the first row gets NA.
    ## Note that each factor uses the levels Good and Bad in the same order, hoping to get
    ## the levels encoded as their underlying integers exactly the same.
    df <- subset(transform(df,                         # Encode indicators, drop originals
                           InflationIndic     = factor(ifelse(Inflation <= inflTarget, "Good", "Bad")),
                           U6Indic            = factor(c(NA, ifelse(diff(U6)   <= 0, "Good", "Bad"))),
                           LFPRIndic          = factor(c(NA, ifelse(diff(LFPR) >= 0, "Good", "Bad"))),
                           GDPGrowthIndic     = factor(ifelse(GDPGrowth >= median(GDPGrowth),
                                                              "Good", "Bad")),
                           GDPGrowthRealIndic = factor(ifelse(GDPGrowthReal >= median(GDPGrowthReal),
                                                              "Good", "Bad")),
                           VFINXIndic         = factor(ifelse(VFINX >= median(VFINX, na.rm = TRUE),
                                                              "Good", "Bad")),
                           VTSMXIndic         = factor(ifelse(VTSMX >= median(VTSMX, na.rm = TRUE),
                                                              "Good", "Bad")),
                           DeficitIndic       = factor(c(NA, ifelse(diff(Deficit)    >= 0,
                                                                    "Good", "Bad"))),
                           DeficitGDPIndic    = factor(c(NA, ifelse(diff(DeficitGDP) >= 0,
                                                                    "Good", "Bad")))),
                 select = -c(Inflation, U6, LFPR, GDPGrowth, GDPGrowthReal,
                             VFINX, VTSMX, Deficit, DeficitGDP))
    cat(sprintf("\n  - Result has %d rows and %d columns: %s",
                nrow(df), ncol(df), paste(colnames(df), collapse = ", ")))
    checkFactorLevels(df$"InflationIndic",     c("Good", "Bad"))
    checkFactorLevels(df$"U6Indic",            c("Good", "Bad"))
    checkFactorLevels(df$"LFPRIndic",          c("Good", "Bad"))
    checkFactorLevels(df$"GDPGrowthIndic",     c("Good", "Bad"))
    checkFactorLevels(df$"GDPGrowthRealIndic", c("Good", "Bad"))
    checkFactorLevels(df$"VFINXIndic",         c("Good", "Bad"))
    checkFactorLevels(df$"VTSMXIndic",         c("Good", "Bad"))
    checkFactorLevels(df$"DeficitIndic",       c("Good", "Bad"))
    checkFactorLevels(df$"DeficitGDPIndic",    c("Good", "Bad"))

    f <- file.path(resultsDir, omnibusCodedFile)       # Complete pathname of save file
    saveDataframe(df, f)                               # Write out the coded data
    cat(sprintf("\n  - Coded data for regression saved to %s.\n", f))

    df                                                 # Return coded data
  }                                                    #

  doRegressions <- function(omnibusDataCoded, resultsDir, cvPlotFile, doInteractions) {
    cat(sprintf("* Logistic regression of outcome vars on partisanship vars: doInteractions = %s",
                doInteractions))                       #
    depVars   <- grep("^.*Indic$", names(omnibusDataCoded), value = TRUE)
    indepVars <- if (doInteractions)                   #
                   setdiff(names(omnibusDataCoded), c("Years", depVars))
                 else                                  #
                   c("House", "Senate", "President")   #
    tbl       <- ldply(depVars, function(depVar) {     #
      cat(sprintf("\n  - Regression predicting %s\n", depVar))
      ## Get just the dependent variable and the indpendent variables to predict it
      foo <- subset(omnibusDataCoded, select = c(depVar, indepVars))
      foo <- subset(foo, subset = complete.cases(foo)) # *** Normally a bad idea; pure fn of time here?
      ## glmnet, unlike everybody else, wants a matrix and a vector, not a dataframe
      x   <- as.matrix(subset(foo, select = indepVars))#
      y   <- foo[, depVar]                             #
      mdl <- cv.glmnet(x = x, y = y,                   # Predictors and class outputs
                       ## "glmnet is (almost) all you need" recommends LOOCV when posible, though
                       ##   computationally it costs the most rounds of crossvalidation
                       ## https://glmnet.stanford.edu/book/cross-validation.html#how-to-choose-k
                       ##
                       ## "In our extensive simulations, we have found that as 𝐾 increases,
                       ## the bias in CV error decreases significantly, while the variance does not
                       ## increase much. As such, we recommend using LOOCV in situations where run
                       ## time is not an issue. For all other cases, we recommend using industry
                       ## norms 𝐾 = 5 or 𝐾 =10."
                       nfolds       = nrow(foo),       # LOOCV
                       family       = "binomial",      # Logistic regression for binary classification
                       type.measure = "class",         # Misclassification error rate
                       alpha        = 1)               # LASSO, no ridge/elastic net
      f <- file.path(resultsDir, sprintf(cvPlotFile, depVar))
      withPNG(f, 1000, 1000, FALSE, function() {       #
        withPars(function() {                          #
          plot(mdl)                                    #
          title(main = sprintf("Misclassification of %s vs Number of Predictors", depVar), line = +3)
        }, pty = "m",                                  # Maximal plotting area
           bg  = "white",                              # White background
           ps  = 18,                                   # Larger type size for file capture
           mar = c(4, 4, 5, 1))                        # Pull in on margins
      })                                               #
      cat(sprintf("\n    o Crossvalidation plot to %s", f))

      cat("\n    o Regression results\n")              # See what fish we caught
      print(mdl)                                       # Shows lambda.min & lambda.1se results
      print(coef(mdl, s = "lambda.min"))               # Shows regression coefficients
      print(confusion.glmnet(mdl, newx = x, newy = y, s = "lambda.min"))
      ## Gets all the performance measures, even though we minimized misclassification only
      foo   <- assess.glmnet(mdl, newx = x, newy = y, s = "lambda.min")
      foodf <- data.frame("Measure" = sapply(foo, function(x) { attr(x, "measure") }),
                          "Value"   = sapply(foo, function(x) { x }))
      rownames(foodf) <- NULL                          # Performance measures as a table
      print(foodf)                                     #
      ## I don't understand the output of roc.glmnet()
      ## print(roc.glmnet(mdl, newx = x, newy = y, s = "lambda.min"))

      ## Mann-Whitney: score training data w/probability (type = "response"), sort
      ## on that and do mw test on "Good" to see if it's enriched.  Print tbl, report p-value.
      df  <- data.frame("y"          = y,              #
                        "lambda.min" = predict(mdl, newx = x, type = "response", s = "lambda.min"))
      df  <- df[order(df$"lambda.min"), ]              #
      tst <- wilcox.test(as.formula(lambda.min ~ y), data = df, exact = FALSE) # ties!
      print(tst)                                       #

      coefmx <- coef(mdl)                              #
      vars   <- paste(ldply(rownames(coefmx), function(rn) {
        if (rn == "(Intercept)" || coefmx[rn,1] == 0)  #
          NULL                                         #
        else                                           #
          data.frame("X" = sprintf("%s = %.2f", rn, coefmx[rn, 1]) )})$"X", collapse = ", ")
      data.frame("DepVar"            = depVar,         #
                 "Predictors"        = paste(vars, collapse = ", "),
                 "Misclassification" = mdl$"cvm"[mdl$"lambda" == mdl$"lambda.min"],
                 "MannWhitney"       = tst$"p.value")  #
    })                                                 #

    cat("\n")                                          #
    tbl                                                # Return table of regression measures
  }                                                    #

  ##
  ## Main body of script begins here
  ##

  withTranscript(dataDir, resultsDir, txFile, "Outcomes vs Partisanship", function() {
    heraldPhase("Loading data")                        # First, go get the data
    maybeAssign("omnibusData", function() {            # Load pieces, combine, and save dataset
      consolidateByYears(list(loadPartisanshipData(dataDir, partisanshipFile),
                              loadInflationData(dataDir, inflationFile),
                              loadUnemploymentData(dataDir, unemplU6File, unemplLFPRFile, minYr),
                              loadGDPData(dataDir, gdpGrowthFile, gdpRealGrowthFile),
                              loadStockData(dataDir, vfinxFile, vtsmxFile, minYr),
                              loadDeficitData(dataDir, deficitFile, deficitGDPFile)),
                         resultsDir, omnibusDataFile)  # Where to save consollidated data spreadsheet
    })                                                 #

    heraldPhase("Partisan crosstabulations")           # Do branches embrace parties differently?
    maybeAssign("crosstabsDone", function() { partisanCrosstabs(omnibusData) })

    heraldPhase("Outcomes bicluster")                  # What are the INDEPENDENT outcomee variables?
    maybeAssign("biclusterDone", function() {          #
      biclusterOutcomes(omnibusData, c("Inflation", "U6", "LFPR", "GDPGrowth", "GDPGrowthReal",
                                       "VFINX", "VTSMX", "Deficit", "DeficitGDP"),
                        resultsDir, biclFile)          #
    })                                                 #

    heraldPhase("Codings for regression analysis")     # Encode variables for regression: R content
    maybeAssign("omnibusDataCoded", function() {       #  of predictors, Goood/Bad for outcomes
      doCodings(omnibusData, inflTarget, resultsDir, omnibusCodedFile)
    })                                                 #

    heraldPhase("Regressions")                         # Now let's build some models
    maybeAssign("regressionResults", function() {      #  and see if we can predict anything
      doRegressions(omnibusDataCoded, resultsDir, cvPlotFile, doInteractions)
    })                                                 #

    print(regressionResults)                           # Print regression results to transcript
  })                                                   # Done!
}                                                      #
